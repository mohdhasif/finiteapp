import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
    View,
    Animated,
    PanResponder,
    Dimensions,
    StyleSheet,
    TouchableOpacity,
    ViewStyle,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

const { height: SCREEN_HEIGHT } = Dimensions.get('window');

export interface DraggableBottomSheetProps {
    children: React.ReactNode;
    snapPoints?: number[];
    initialSnapIndex?: number;
    onSnapChange?: (index: number) => void;
    backgroundColor?: string;
    borderRadius?: number;
    handleColor?: string;
    style?: ViewStyle;
    enablePanDownToClose?: boolean;
    onClose?: () => void;
}

const DraggableBottomSheet: React.FC<DraggableBottomSheetProps> = ({
    children,
    snapPoints = [0, SCREEN_HEIGHT * 0.25, SCREEN_HEIGHT * 0.75],
    initialSnapIndex = 1,
    onSnapChange,
    backgroundColor = '#FFFFFF',
    borderRadius = 30,
    handleColor = '#999',
    style,
    enablePanDownToClose = false,
    onClose,
}) => {
    const slideAnim = useRef(new Animated.Value(snapPoints[initialSnapIndex])).current;
    const lastPosition = useRef(snapPoints[initialSnapIndex]);
    const [currentSnapIndex, setCurrentSnapIndex] = useState(initialSnapIndex);

    // Update animation value when snapPoints change
    useEffect(() => {
        slideAnim.setValue(snapPoints[initialSnapIndex]);
        lastPosition.current = snapPoints[initialSnapIndex];
        setCurrentSnapIndex(initialSnapIndex);
    }, [snapPoints, initialSnapIndex, slideAnim]);

    const snapTo = useCallback((targetIndex: number) => {
        if (targetIndex < 0 || targetIndex >= snapPoints.length) return;
        
        const targetValue = snapPoints[targetIndex];
        Animated.spring(slideAnim, {
            toValue: targetValue,
            useNativeDriver: false,
            friction: 9,
            tension: 90,
        }).start(() => {
            lastPosition.current = targetValue;
            setCurrentSnapIndex(targetIndex);
            onSnapChange?.(targetIndex);
        });
    }, [snapPoints, slideAnim, onSnapChange]);

    const panResponder = useRef(
        PanResponder.create({
            onStartShouldSetPanResponder: () => true,
            onMoveShouldSetPanResponder: (_, gestureState) => {
                // More responsive - capture any vertical movement
                return Math.abs(gestureState.dy) > 5;
            },
            onPanResponderGrant: () => {
                // Handle drag started
            },
            onPanResponderMove: (_, gestureState) => {
                let newY = lastPosition.current + gestureState.dy;
                const minY = snapPoints[0];
                const maxY = snapPoints[snapPoints.length - 1];
                newY = Math.max(minY, Math.min(newY, maxY));
                slideAnim.setValue(newY);
            },
            onPanResponderRelease: (_, gestureState) => {
                const projected = lastPosition.current + gestureState.dy + gestureState.vy * 100;
                
                // Find nearest snap point
                let nearestIndex = 0;
                let minDistance = Math.abs(projected - snapPoints[0]);
                
                for (let i = 1; i < snapPoints.length; i++) {
                    const distance = Math.abs(projected - snapPoints[i]);
                    if (distance < minDistance) {
                        minDistance = distance;
                        nearestIndex = i;
                    }
                }
                
                // Add bias for better snapping
                const biasRadius = 80;
                if (snapPoints.length >= 3) {
                    // Bias towards middle position
                    const middleIndex = 1;
                    if (Math.abs(projected - snapPoints[middleIndex]) <= biasRadius) {
                        nearestIndex = middleIndex;
                    }
                }
                
                snapTo(nearestIndex);
            },
        })
    ).current;

    return (
        <Animated.View
            {...panResponder.panHandlers}
            style={[
                styles.container,
                {
                    transform: [{ translateY: slideAnim }],
                    backgroundColor,
                    borderTopLeftRadius: borderRadius,
                    borderTopRightRadius: borderRadius,
                },
                style,
            ]}
        >
            {/* Handle */}
            <View style={styles.handle}>
                <View style={styles.handleBar} />
            </View>
            
            {/* Content */}
            <View style={styles.content}>
                {children}
            </View>
        </Animated.View>
    );
};

const styles = StyleSheet.create({
    container: {
        position: 'absolute',
        left: 0,
        right: 0,
        height: SCREEN_HEIGHT,
        elevation: 15,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: -4,
        },
        shadowOpacity: 0.15,
        shadowRadius: 12,
    },
    handle: {
        alignSelf: 'center',
        marginTop: 12,
        marginBottom: 16,
        width: '100%',
        alignItems: 'center',
        paddingTop: 8,
    },
    handleBar: {
        width: 50,
        height: 5,
        backgroundColor: '#ddd',
        borderRadius: 3,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.1,
        shadowRadius: 2,
        elevation: 2,
    },
    content: {
        flex: 1,
        paddingHorizontal: 20,
        paddingTop: 4,
    },
});

export default DraggableBottomSheet;
