import React, { createContext, useState, useContext, ReactNode } from 'react';

type UserRole = 'client' | 'admin' | 'freelancer' | null;

interface AuthContextType {
    isAuthenticated: boolean;
    role: UserRole;
    login: (role: UserRole) => void;
    logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
    const [role, setRole] = useState<UserRole>(null);
    const isAuthenticated = !!role;

    const login = (userRole: UserRole) => setRole(userRole);
    const logout = () => setRole(null);

    return (
        <AuthContext.Provider value={{ isAuthenticated, role, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext)!;
