// src/screens/AdminTaskDetailsScreen.tsx
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    Dimensions,
    Linking,
    Alert,
    TextInput,
    RefreshControl,
    ActivityIndicator,
    KeyboardAvoidingView,
    Platform,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { useRoute, RouteProp, useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/types';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
    listAttachments,
    uploadAttachment,
    deleteAttachment,
    getTaskLink,
    setTaskLink,
    listNotes,
    addNote,
    type TaskAttachment,
    type TaskNote,
} from '../services/taskDetailsService';
import { BASE_URL } from '../constants/apiConfig';
import { launchImageLibrary } from 'react-native-image-picker';
import DocumentPicker, { types } from 'react-native-document-picker';
import { getTaskDetails } from '../services/taskService';
import Modal from 'react-native-modal';
import {
    listTaskAssignees,
    assignTaskAssignee,
    removeTaskAssignee,
    updateTaskAssigneeRole,
    type Assignee,
    searchFreelancersSimple,
    type NewAssignee,
} from '../services/taskAssigneesService';
import { useAsyncState } from '../hooks/useOptimizedState';
import { performanceMonitor } from '../utils/performance';
import OptimizedBottomTab from '../components/OptimizedBottomTab';

const { width } = Dimensions.get('window');
type ScreenRoute = RouteProp<RootStackParamList, 'AdminTaskDetailsScreen'>;

    // Normalize date → milliseconds (handle "YYYY-MM-DD HH:mm:ss" or ISO)
const toMs = (s?: string) => {
    if (!s) return 0;
    const iso = s.includes('T') ? s : s.replace(' ', 'T') + 'Z';
    const t = Date.parse(iso);
    return Number.isFinite(t) ? t : 0;
};
    // Sort helper: oldest → newest (only used during load)
const sortOldest = (arr: TaskNote[]) => arr.slice().sort((a, b) => toMs(a.created_at) - toMs(b.created_at));

const AdminTaskDetailsScreen: React.FC = () => {
    const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
    const route = useRoute<ScreenRoute>();
    const taskId = route.params?.task_id as number;
    const taskTitle = route.params?.task_title ?? 'Task';

    const [token, setToken] = useState<string>('');
    const [refreshing, setRefreshing] = useState(false);

    // Performance optimized state management
    const { data: taskDetails, loading, error, execute: fetchTaskDetails } = useAsyncState<any>(null);
    const { data: attachments, execute: fetchAttachments } = useAsyncState<TaskAttachment[]>([]);
    const { data: notes, execute: fetchNotes } = useAsyncState<TaskNote[]>([]);
    const { data: assignees, execute: fetchAssignees } = useAsyncState<Assignee[]>([]);
    
    // UI states
    const [uploading, setUploading] = useState(false);
    const [linkUrl, setLinkUrlState] = useState<string>('');
    const [savingLink, setSavingLink] = useState(false);
    const [noteText, setNoteText] = useState('');
    const [sendingNote, setSendingNote] = useState(false);

    const [showAddModal, setShowAddModal] = useState(false);
    const [adding, setAdding] = useState(false);
    const [options, setOptions] = useState<NewAssignee[]>([]);

    const ROLE_OPTIONS: Assignee['role'][] = ['designer', 'editor', 'strategist', 'pm', 'other'];

    const outerScrollRef = useRef<ScrollView>(null); // overall scroll
    const notesBottomAnchor = useRef<View>(null);     // anchor for scrolling to bottom

    const canSend = useMemo(() => noteText.trim().length > 0, [noteText]);
    
    // Performance monitoring
    const renderCount = useRef(0);
    renderCount.current++;
    const [searchQ, setSearchQ] = useState('');
    const [loadingOptions, setLoadingOptions] = useState(false);

    const toAbs = useCallback((u?: string | null) => {
        if (!u) return '';
        if (/^https?:\/\//i.test(u)) return u;
        return `${BASE_URL.replace(/\/+$/, '')}/${String(u).replace(/^\/+/, '')}`;
    }, []);

    const loadAll = useCallback(async (tk: string) => {
        performanceMonitor.startTimer('loadTaskDetails');
        
        try {
            // Load all data in parallel using optimized async state
            await Promise.all([
                fetchTaskDetails(async () => {
                    return await getTaskDetails(tk, taskId);
                }),
                fetchAttachments(async () => {
                    return await listAttachments(tk, taskId);
                }),
                fetchNotes(async () => {
                    const notesData = await listNotes(tk, taskId);
                    return sortOldest(notesData ?? []);
                }),
                fetchAssignees(async () => {
                    return await listTaskAssignees(tk, taskId);
                })
            ]);
            
            // Load link separately since it's not part of async state
            const linkData = await getTaskLink(tk, taskId);
            setLinkUrlState(linkData?.url ?? '');
            
        } catch (e: any) {
            Alert.alert('Failed to load', e?.message || 'Unknown error');
        } finally {
            performanceMonitor.endTimer('loadTaskDetails');
        }
    }, [taskId, fetchTaskDetails, fetchAttachments, fetchNotes, fetchAssignees]);


    const onRefresh = useCallback(async () => {
        if (!token) return;
        setRefreshing(true);
        try {
            await loadAll(token);
        } finally {
            setRefreshing(false);
        }
    }, [token, loadAll]);

    useEffect(() => {
        (async () => {
            const tk = (await AsyncStorage.getItem('userToken')) || '';
            setToken(tk);
            if (!taskId) {
                Alert.alert('Error', 'task_id is missing.');
                return;
            }
            await loadAll(tk);
        })();
    }, [taskId, loadAll]);

    // ===== Actions =====
    const handlePickAndUpload = useCallback(async () => {
        if (!token) return;
        try {
            performanceMonitor.startTimer('uploadAttachment');
            const res = await DocumentPicker.pickSingle({
                type: [types.allFiles], // all file types
            });

            const uri = res.uri;
            if (!uri) return;

            setUploading(true);
            const name = res.name || `attachment_${Date.now()}`;
            const type = res.type || 'application/octet-stream';

            const success = await uploadAttachment(token, taskId, { uri, name, type });
            if (success) {
                // ✅ FIXED: Always fetch fresh data from server
                await fetchAttachments(async () => {
                    return await listAttachments(token, taskId);
                });
                Alert.alert('Success', 'Attachment uploaded successfully.');
            } else {
                Alert.alert('Failed', 'Upload failed. Please try again.');
            }
        } catch (err: any) {
            if (!DocumentPicker.isCancel(err)) {
                Alert.alert('Upload failed', err?.message || 'Unknown error');
            }
        } finally {
            setUploading(false);
            performanceMonitor.endTimer('uploadAttachment');
        }
    }, [token, taskId, fetchAttachments]);

    const handleDeleteAttachment = (id: number) => {
        if (!token) return;
        Alert.alert('Delete attachment?', 'This action cannot be undone.', [
            { text: 'Cancel', style: 'cancel' },
            {
                text: 'Delete',
                style: 'destructive',
                onPress: async () => {
                    try {
                        const ok = await deleteAttachment(token, id);
                        if (ok) {
                            // ✅ OPTIMIZED: Remove from existing attachments without fetching from server
                            await fetchAttachments(async () => {
                                const currentAttachments = attachments || [];
                                return currentAttachments.filter((x: TaskAttachment) => x.id !== id);
                            });
                        } else {
                            Alert.alert('Failed', 'Cannot delete attachment.');
                        }
                    } catch (e: any) {
                        Alert.alert('Failed', e?.message || 'Unknown error');
                    }
                },
            },
        ]);
    };

    const normalizeUrl = (s: string) => {
        const trimmed = (s || '').trim();
        return /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
    };

    const handleOpenLink = async () => {
        if (!linkUrl?.trim()) return;
        const url = normalizeUrl(linkUrl);

        try {
            await Linking.openURL(url); // terus cuba
        } catch (e) {
            Alert.alert('Invalid link', 'URL cannot be opened. Make sure you have a browser or try again.');
        }
    };

    const handleSaveLink = async () => {
        if (!token) return;
        setSavingLink(true);
        try {
            await setTaskLink(token, taskId, linkUrl.trim());
            Alert.alert('Success', 'Link has been saved.');
        } catch (e: any) {
            Alert.alert('Failed', e?.message || 'Unknown error');
        } finally {
            setSavingLink(false);
        }
    };

    const handleSendNote = async () => {
        if (!token || !canSend) return;
        setSendingNote(true);
        try {
            const note = await addNote(token, {
                task_id: taskId,
                sender_type: 'admin',
                message: noteText.trim(),
            });

            // Fallback created_at if server doesn't provide, so sorting isn't weird
            const safeNote: TaskNote = {
                ...note,
                created_at: note.created_at && note.created_at.trim() ? note.created_at : new Date().toISOString(),
            };

            // ✅ OPTIMIZED: Append to existing notes without fetching from server
            await fetchNotes(async () => {
                const currentNotes = notes || [];
                return [...currentNotes, safeNote];
            });
            setNoteText('');

            // Auto-scroll to bottom to show new note
            requestAnimationFrame(() => {
                outerScrollRef.current?.scrollToEnd({ animated: true });
            });
        } catch (e: any) {
            Alert.alert('Failed to send note', e?.message || 'Unknown error');
        } finally {
            setSendingNote(false);
        }
    };

    const openAddAssignee = () => { setShowAddModal(true); /* call fetch options here if needed */ };

    const fetchOptions = useCallback(async () => {
        if (!token) return;
        try {
            setLoadingOptions(true);
            const rows = await searchFreelancersSimple(token, {
                q: searchQ.trim(),
                only_active: 1,
                page: 1,
                per_page: 20,
            });
            setOptions(rows);
        } catch (e: any) {
            Alert.alert('Failed', e?.message || 'Cannot load freelancer list.');
            setOptions([]);
        } finally {
            setLoadingOptions(false);
        }
    }, [token, searchQ]);

    useEffect(() => {
        if (showAddModal) {
            fetchOptions();
        } else {
            setOptions([]);
            setSearchQ('');
        }
    }, [showAddModal, fetchOptions]);


    const handleRemoveAssignee = (fid: number) => {
        if (!token) return;
        Alert.alert('Remove freelancer?', 'Freelancer will be removed from this task.', [
            { text: 'Cancel', style: 'cancel' },
            {
                text: 'Remove', style: 'destructive',
                onPress: async () => {
                    try {
                        await removeTaskAssignee(token, taskId, fid);
                        
                        // ✅ OPTIMIZED: Remove from existing assignees without fetching from server
                        await fetchAssignees(async () => {
                            const currentAssignees = assignees || [];
                            return currentAssignees.filter((a: Assignee) => a.id !== fid);
                        });
                    } catch (e: any) {
                        Alert.alert('Failed', e?.message || 'Cannot remove.');
                    }
                }
            }
        ]);
    };

    const handleChangeRole = async (fid: number, role: Assignee['role']) => {
        if (!token) return;
        try {
            await updateTaskAssigneeRole(token, taskId, fid, role);
            
            // ✅ OPTIMIZED: Update existing assignees without fetching from server
            await fetchAssignees(async () => {
                const currentAssignees = assignees || [];
                return currentAssignees.map((a: Assignee) => 
                    a.id === fid ? { ...a, role } : a
                );
            });
        } catch (e: any) {
            Alert.alert('Failed', e?.message || 'Cannot update role.');
        }
    };

    const handleSelectToAdd = async (f: NewAssignee) => {
        if (!token) return;
        
        // Check if freelancer is already assigned to prevent duplicates
        const isAlreadyAssigned = (assignees || []).some(a => a.id === f.id);
        if (isAlreadyAssigned) {
            Alert.alert('Already Assigned', 'This freelancer is already assigned to this task.');
            return;
        }
        
        try {
            setAdding(true);
            await assignTaskAssignee(token, taskId, f.id, 'other'); // default role
            
            // ✅ OPTIMIZED: Add to existing assignees without fetching from server
            await fetchAssignees(async () => {
                const currentAssignees = assignees || [];
                const newAssignee: Assignee = {
                    id: f.id,
                    name: f.name,
                    email: f.email || '',
                    role: 'other'
                };
                return [...currentAssignees, newAssignee];
            });
            
            setShowAddModal(false);
            setOptions([]);
            setSearchQ('');
        } catch (e: any) {
            Alert.alert('Failed', e?.message || 'Cannot assign.');
        } finally {
            setAdding(false);
        }
    };

    return (
        <KeyboardAvoidingView 
            style={styles.container} 
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
        >


            <ScrollView
                ref={outerScrollRef}
                contentContainerStyle={styles.scrollContent}
                refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
                keyboardShouldPersistTaps="handled"
                showsVerticalScrollIndicator={false}
            >

                {/* Header */}
                <Text style={styles.header}>Task Details</Text>
                <Text style={styles.title}>{taskTitle}</Text>

                {/* Description (placeholder) */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>
                        <Text style={styles.bullet}>● </Text>Description
                    </Text>
                    <Text style={styles.description}>
                        {taskDetails?.description || 'No description.'}
                    </Text>
                </View>

                {/* Attachments */}
                <View style={styles.cardBlock}>
                    <View style={styles.cardHeaderRow}>
                        <Text style={styles.cardTitle}>● Attachments</Text>
                        <TouchableOpacity style={styles.iconBtn} onPress={handlePickAndUpload} disabled={uploading}>
                            {uploading ? (
                                <ActivityIndicator size="small" color="#fff" />
                            ) : (
                                <Icon name="cloud-upload-outline" size={18} color="#fff" />
                            )}
                            <Text style={styles.iconBtnText}>{uploading ? 'Uploading...' : 'Upload'}</Text>
                        </TouchableOpacity>
                    </View>

                    {loading && (attachments || []).length === 0 ? (
                        <Text style={styles.muted}>Loading attachments…</Text>
                    ) : (attachments || []).length === 0 ? (
                        <Text style={styles.muted}>No attachments.</Text>
                    ) : (
                        (attachments || []).map((att) => (
                            <View key={att.id} style={styles.attachmentRow}>
                                <View style={{ flex: 1 }}>
                                    <Text style={styles.attachmentName} numberOfLines={1}>
                                        {att.file_name || 'file'}
                                    </Text>
                                    <TouchableOpacity onPress={() => Linking.openURL(toAbs(att.file_url))}>
                                        <Text style={styles.attachmentUrl} numberOfLines={1}>
                                            {toAbs(att.file_url)}
                                        </Text>
                                    </TouchableOpacity>
                                </View>
                                <TouchableOpacity onPress={() => handleDeleteAttachment(att.id)} style={styles.deleteBtn}>
                                    <Icon name="trash-outline" size={20} color="#fff" />
                                </TouchableOpacity>
                            </View>
                        ))
                    )}
                </View>

                {/* Single Link */}
                <View style={styles.cardBlock}>
                    <Text style={styles.cardTitle}>● Link</Text>
                    <View style={styles.linkRow}>
                        <TextInput
                            placeholder="https://example.com/doc"
                            placeholderTextColor="#9dc9e4"
                            style={styles.input}
                            value={linkUrl}
                            onChangeText={setLinkUrlState}
                            autoCapitalize="none"
                            autoCorrect={false}
                        />
                    </View>
                    <View style={styles.rowActions}>
                        <TouchableOpacity style={styles.secondaryBtn} onPress={handleOpenLink} disabled={!linkUrl}>
                            <Icon name="open-outline" size={18} color="#fff" />
                            <Text style={styles.secondaryBtnText}>Open</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.primaryBtn} onPress={handleSaveLink} disabled={savingLink}>
                            {savingLink ? (
                                <ActivityIndicator size="small" color="#0B2C3F" />
                            ) : (
                                <Icon name="save-outline" size={18} color="#0B2C3F" />
                            )}
                            <Text style={styles.primaryBtnText}>{savingLink ? 'Saving…' : 'Save'}</Text>
                        </TouchableOpacity>
                    </View>
                </View>

                {/* START ASSIGNEE */}
                {/* Assignees */}
                <View style={styles.cardBlock}>
                    <View style={styles.cardHeaderRow}>
                        <Text style={styles.cardTitle}>● Assignees</Text>
                        <TouchableOpacity style={styles.iconBtn} onPress={openAddAssignee}>
                            <Icon name="person-add-outline" size={18} color="#fff" />
                            <Text style={styles.iconBtnText}>Add</Text>
                        </TouchableOpacity>
                    </View>

                    {loading && (assignees || []).length === 0 ? (
                        <Text style={styles.muted}>Loading assignees…</Text>
                    ) : (assignees || []).length === 0 ? (
                        <Text style={styles.muted}>No freelancers assigned yet.</Text>
                    ) : (
                        (assignees || []).map(a => (
                            <View key={a.id} style={styles.attachmentRow}>
                                <View style={{ flex: 1 }}>
                                    <Text style={styles.attachmentName} numberOfLines={1}>{a.name}</Text>
                                    <Text style={styles.attachmentUrl} numberOfLines={1}>{a.email || '—'}</Text>
                                    {/* Role picker ringkas */}
                                    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 6 }}>
                                        {ROLE_OPTIONS.map(r => (
                                            <TouchableOpacity
                                                key={r}
                                                onPress={() => handleChangeRole(a.id, r)}
                                                style={{
                                                    paddingHorizontal: 10, paddingVertical: 6, borderRadius: 16, marginRight: 6,
                                                    backgroundColor: a.role === r ? '#1DA1F2' : '#0E4766', borderWidth: 1, borderColor: '#1DA1F2'
                                                }}
                                            >
                                                <Text style={{ color: a.role === r ? '#0B2C3F' : '#9dc9e4', fontWeight: '700', fontSize: 12 }}>
                                                    {r.toUpperCase()}
                                                </Text>
                                            </TouchableOpacity>
                                        ))}
                                    </ScrollView>
                                </View>
                                <TouchableOpacity onPress={() => handleRemoveAssignee(a.id)} style={styles.deleteBtn}>
                                    <Icon name="trash-outline" size={20} color="#fff" />
                                </TouchableOpacity>
                            </View>
                        ))
                    )}
                </View>

                {/* END ASSIGNEE */}

                {/* Notes */}
                <View style={styles.cardBlock}>
                    <Text style={styles.cardTitle}>● Notes</Text>

                    {/* Note list (oldest → newest) — sorted during load */}
                    {loading && (notes || []).length === 0 ? (
                        <Text style={styles.muted}>Loading notes…</Text>
                    ) : (notes || []).length === 0 ? (
                        <Text style={styles.muted}>No notes yet.</Text>
                    ) : (
                        (notes || []).map((n) => (
                            <View key={n.id} style={styles.noteRow}>
                                <View style={styles.noteBadge}>
                                    <Text style={styles.noteBadgeText}>{n.sender_type === 'admin' ? 'A' : 'C'}</Text>
                                </View>
                                <View style={{ flex: 1 }}>
                                    <Text style={styles.noteMeta}>
                                        {n.sender_type.toUpperCase()} · {new Date(toMs(n.created_at)).toLocaleString()}
                                    </Text>
                                    <Text style={styles.noteText}>{n.message}</Text>
                                </View>
                            </View>
                        ))
                    )}

                    {/* INPUT di PALING BAWAH */}
                    <View style={[styles.noteInputBox, { marginTop: 12 }]}>
                        <TextInput
                            placeholder="Write a note…"
                            placeholderTextColor="#9dc9e4"
                            style={styles.textarea}
                            value={noteText}
                            onChangeText={setNoteText}
                            multiline
                        />
                        <TouchableOpacity
                            style={[styles.primaryBtn, { alignSelf: 'flex-end', marginTop: 10, opacity: canSend ? 1 : 0.6 }]}
                            onPress={handleSendNote}
                            disabled={!canSend || sendingNote}
                        >
                            {sendingNote ? (
                                <ActivityIndicator size="small" color="#0B2C3F" />
                            ) : (
                                <Icon name="send-outline" size={18} color="#0B2C3F" />
                            )}
                            <Text style={styles.primaryBtnText}>{sendingNote ? 'Sending…' : 'Send'}</Text>
                        </TouchableOpacity>
                    </View>

                    {/* Precise anchor for scrollToEnd */}
                    <View ref={notesBottomAnchor} />
                </View>

                <View style={{ height: 120 }} />
            </ScrollView>

            {/* Optimized Bottom Tab */}
            <OptimizedBottomTab
                tabs={[
                    {
                        id: 'home',
                        icon: 'home',
                        screen: 'AdminHomeScreen' as keyof RootStackParamList,
                    },
                    {
                        id: 'calendar',
                        icon: 'calendar',
                        screen: 'AdminCalendarScreen' as keyof RootStackParamList,
                    },
                    {
                        id: 'notifications',
                        icon: 'notifications',
                        screen: 'AdminNotificationsScreen' as keyof RootStackParamList,
                    },
                    {
                        id: 'profile',
                        icon: 'person',
                        screen: 'AdminProfileScreen' as keyof RootStackParamList,
                    },
                ]}
                quickActions={[
                    {
                        id: 'new-project',
                        title: 'New Project',
                        icon: 'folder-open',
                        onPress: () => navigation.navigate('AdminCreateProjectScreen'),
                    },
                    {
                        id: 'new-task',
                        title: 'New Task',
                        icon: 'add-circle',
                        onPress: () => navigation.navigate('AddTaskScreen'),
                    },
                ]}
                activeTab="task-details"
            />

            <Modal isVisible={showAddModal} onBackdropPress={() => setShowAddModal(false)} backdropOpacity={0.4} useNativeDriver>
                <View style={{ backgroundColor: '#12668C', borderRadius: 12, padding: 12 }}>
                    <Text style={{ color: '#fff', fontSize: 16, fontWeight: '700', marginBottom: 10 }}>Add Freelancer</Text>
                    <View style={styles.linkRow}>
                        <TextInput
                            placeholder="Search name / email…"
                            placeholderTextColor="#9dc9e4"
                            style={styles.input}
                            value={searchQ}
                            onChangeText={setSearchQ}
                            autoCapitalize="none"
                            onSubmitEditing={fetchOptions}
                        />
                    </View>

                    {loadingOptions ? (
                        <View style={{ paddingVertical: 20 }}><ActivityIndicator size="small" color="#fff" /></View>
                    ) : options.length === 0 ? (
                        <Text style={styles.muted}>No results.</Text>
                    ) : options.filter(opt => !(assignees || []).some(a => a.id === opt.id)).length === 0 ? (
                        <Text style={styles.muted}>All available freelancers are already assigned to this task.</Text>
                    ) : (
                        <ScrollView style={{ maxHeight: 280, marginTop: 10 }}>
                            {options
                                .filter(opt => !(assignees || []).some(a => a.id === opt.id)) // Hide already assigned freelancers
                                .map(opt => (
                                <TouchableOpacity
                                    key={opt.id}
                                    style={[styles.attachmentRow, { backgroundColor: '#0E4766' }]}
                                    onPress={() => handleSelectToAdd(opt)}
                                    disabled={adding}
                                >
                                    <View style={{ flex: 1 }}>
                                        <Text style={styles.attachmentName} numberOfLines={1}>{opt.name}</Text>
                                        {!!opt.email && <Text style={styles.attachmentUrl} numberOfLines={1}>{opt.email}</Text>}
                                    </View>
                                    <Icon name="add-circle-outline" size={22} color="#9ddcff" />
                                </TouchableOpacity>
                            ))}
                        </ScrollView>
                    )}

                    <View style={{ flexDirection: 'row', justifyContent: 'flex-end', marginTop: 12 }}>
                        <TouchableOpacity style={styles.secondaryBtn} onPress={() => setShowAddModal(false)} disabled={adding}>
                            <Icon name="close-outline" size={18} color="#fff" />
                            <Text style={styles.secondaryBtnText}>Close</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>

        </KeyboardAvoidingView>
    );
};

export default AdminTaskDetailsScreen;

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#0B2C3F' },
    scrollContent: { padding: 20 },
    header: { fontSize: 26, color: '#fff', fontWeight: 'bold' },
    title: { fontSize: 20, color: '#fff', marginBottom: 20 },

    section: {
        backgroundColor: '#0E4766',
        padding: 15,
        borderRadius: 10,
        borderColor: '#1DA1F2',
        borderWidth: 1,
        marginBottom: 20,
    },
    sectionTitle: { color: '#fff', fontWeight: 'bold', fontSize: 16, marginBottom: 8 },
    bullet: { color: '#fff', fontSize: 16 },
    description: { color: '#ccc', fontSize: 14, lineHeight: 20 },

    cardBlock: {
        backgroundColor: '#12668C',
        padding: 15,
        borderRadius: 10,
        marginBottom: 15,
    },
    cardHeaderRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
    cardTitle: { color: '#fff', fontSize: 16, marginBottom: 10 },

    iconBtn: {
        flexDirection: 'row',
        gap: 8,
        backgroundColor: '#0B2C3F',
        borderRadius: 8,
        paddingVertical: 8,
        paddingHorizontal: 12,
        alignItems: 'center',
    },
    iconBtnText: { color: '#fff', fontWeight: '600' },

    attachmentRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        backgroundColor: '#0E4766',
        padding: 10,
        borderRadius: 8,
        marginBottom: 8,
    },
    attachmentName: { color: '#fff', fontSize: 14, fontWeight: '600' },
    attachmentUrl: { color: '#9ddcff', fontSize: 12, marginTop: 2 },
    deleteBtn: {
        backgroundColor: '#d9534f',
        width: 36,
        height: 36,
        borderRadius: 8,
        alignItems: 'center',
        justifyContent: 'center',
    },

    linkRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    input: {
        flex: 1,
        backgroundColor: '#0E4766',
        borderRadius: 8,
        paddingHorizontal: 12,
        paddingVertical: 10,
        color: '#fff',
        borderWidth: 1,
        borderColor: '#1DA1F2',
    },
    rowActions: { flexDirection: 'row', gap: 10, marginTop: 10, justifyContent: 'flex-end' },
    secondaryBtn: {
        flexDirection: 'row',
        gap: 8,
        backgroundColor: '#0E4766',
        borderRadius: 8,
        paddingVertical: 8,
        paddingHorizontal: 12,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#1DA1F2',
    },
    secondaryBtnText: { color: '#fff', fontWeight: '600' },
    primaryBtn: {
        flexDirection: 'row',
        gap: 8,
        backgroundColor: '#fff',
        borderRadius: 8,
        paddingVertical: 8,
        paddingHorizontal: 12,
        alignItems: 'center',
    },
    primaryBtnText: { color: '#0B2C3F', fontWeight: '700' },

    noteInputBox: {
        backgroundColor: '#0E4766',
        borderRadius: 10,
        borderColor: '#1DA1F2',
        borderWidth: 1,
        padding: 12,
        marginBottom: 0,
    },
    textarea: {
        minHeight: 80,
        color: '#fff',
        textAlignVertical: 'top',
    },
    noteRow: {
        flexDirection: 'row',
        gap: 10,
        backgroundColor: '#0E4766',
        borderRadius: 10,
        padding: 12,
        marginBottom: 8,
    },
    noteBadge: {
        width: 28,
        height: 28,
        borderRadius: 14,
        backgroundColor: '#1DA1F2',
        alignItems: 'center',
        justifyContent: 'center',
    },
    noteBadgeText: { color: '#0B2C3F', fontWeight: '800' },
    noteMeta: { color: '#9dc9e4', fontSize: 11, marginBottom: 4 },
    noteText: { color: '#fff', fontSize: 14 },
    muted: { color: '#cfe7f6', opacity: 0.7 },


});
