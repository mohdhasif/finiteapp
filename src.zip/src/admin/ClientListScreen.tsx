import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    TouchableOpacity,
    RefreshControl,
    Dimensions,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/Ionicons'; // Pastikan import icon
import LinearGradient from 'react-native-linear-gradient';

const { width } = Dimensions.get('window');

type Client = {
    client_id: number;
    name: string;
    email: string;
    company_name: string;
    phone: string;
    client_status: string;
};

const statusColors: Record<string, string> = {
    approved: '#00C851',
    pending: '#ffbb33',
    rejected: '#ff4444',
    active: '#33b5e5',
    'non-active': '#888',
};

const filterOptions = [
    'All',
    'Pending',
    'Approved',
    'Rejected',
    'Active',
    'Non-Active',
] as const;

const ClientListScreen = () => {
    const [clients, setClients] = useState<Client[]>([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [selectedFilter, setSelectedFilter] = useState<typeof filterOptions[number]>('All');
    const [dropdownVisible, setDropdownVisible] = useState(false);

    const fetchClients = async () => {
        try {
            const token = await AsyncStorage.getItem('userToken');
            let url = 'https://fd9315becb7e.ngrok-free.app/get_clients.php';

            if (selectedFilter !== 'All') {
                const statusParam = selectedFilter.toLowerCase();
                url += `?status=${encodeURIComponent(statusParam)}`;
            }

            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });

            const data = await response.json();
            setClients(data);
        } catch (error) {
            console.error('Error fetching clients:', error);
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    useEffect(() => {
        fetchClients();
    }, [selectedFilter]);

    const renderClient = ({ item }: { item: Client }) => (

        <LinearGradient
            colors={['#007bff', '#004c99']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.card}
        >
            <View style={styles.cardRow}>
                <View style={{ flex: 1 }}>
                    <Text style={styles.name}>{item.name}</Text>
                    <Text style={styles.subtext}>{item.company_name}</Text>
                    <Text style={styles.subtext}>{item.email}</Text>
                    <Text style={styles.subtext}>{item.phone}</Text>
                </View>
                <View style={styles.statusContainer}>
                    <View
                        style={[
                            styles.statusDot,
                            { backgroundColor: statusColors[item.client_status] || '#ccc' },
                        ]}
                    />
                    <Text style={styles.statusText}>{item.client_status}</Text>
                </View>
            </View>
        </LinearGradient>
    );

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Clients</Text>

            {/* 🔽 Butang filter style baru */}
            <View style={styles.filterContainer}>
                <TouchableOpacity
                    style={styles.filterButton}
                    onPress={() => setDropdownVisible(!dropdownVisible)}
                >
                    <Text style={styles.filterButtonText}>{selectedFilter}</Text>
                    <Icon
                        name={dropdownVisible ? 'chevron-up-outline' : 'chevron-down-outline'}
                        size={16}
                        color="#999"
                        style={{ marginLeft: 6 }}
                    />
                </TouchableOpacity>

                {/* 🔽 Dropdown menu */}
                {dropdownVisible && (
                    <View style={styles.dropdownMenu}>
                        {['All', 'Pending', 'Approved', 'Rejected', 'Active', 'Non-Active'].map((option, index, arr) => (
                            <TouchableOpacity
                                key={option}
                                style={[
                                    styles.dropdownItem,
                                    selectedFilter === option && styles.dropdownItemActive,
                                    index === 0 && styles.dropdownItemFirst,
                                    index === arr.length - 1 && styles.dropdownItemLast,
                                ]}
                                onPress={() => {
                                    setSelectedFilter(option as any);
                                    setDropdownVisible(false);
                                }}
                            >
                                <Text
                                    style={[
                                        styles.dropdownItemText,
                                        selectedFilter === option && styles.dropdownItemTextActive,
                                    ]}
                                >
                                    {option}
                                </Text>
                            </TouchableOpacity>
                        ))}
                    </View>
                )}
            </View>

            {/* 🔽 Senarai client */}
            <FlatList
                data={clients}
                keyExtractor={(item) => item.client_id.toString()}
                renderItem={renderClient}
                refreshControl={<RefreshControl refreshing={refreshing} onRefresh={fetchClients} />}
                contentContainerStyle={{ paddingBottom: 50 }}
            />
        </View>
    );

};

export default ClientListScreen;

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#E5E5E5', padding: 16 },
    title: { fontSize: 22, fontWeight: 'bold', color: '#004C99', marginBottom: 12 },

    // 🔽 Kad client
    card: {
        backgroundColor: '#007bff',
        borderRadius: 18,
        padding: 16,
        marginBottom: 14,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 3 },
        shadowOpacity: 0.2,
        shadowRadius: 6,
        elevation: 6,
    },
    cardRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
    },
    name: { fontSize: 18, fontWeight: 'bold', color: '#fff', marginBottom: 4 },
    subtext: { fontSize: 14, color: '#e6e6e6', marginBottom: 2 },
    statusContainer: { alignItems: 'center', justifyContent: 'center' },
    statusDot: {
        width: 14,
        height: 14,
        borderRadius: 7,
        marginBottom: 4,
    },
    statusText: { fontSize: 12, color: '#fff', textTransform: 'capitalize' },

    // 🔽 Filter dropdown style baru
    filterContainer: {
        alignItems: 'flex-end',
        marginBottom: 12,
    },
    filterButton: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-end',
        backgroundColor: 'transparent',
        paddingVertical: 6,
        paddingHorizontal: 10,
        borderRadius: 8,
    },
    filterButtonText: {
        color: '#999',
        fontSize: 14,
        marginRight: 6,
    },
    dropdownMenu: {
        position: 'absolute',
        top: 42, // tinggi daripada butang filter
        right: 0,
        backgroundColor: '#fff',
        borderRadius: 12,
        paddingVertical: 6,
        elevation: 5,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 6,
        width: 160,
        zIndex: 999, // untuk pastikan naik atas
    },
    dropdownItem: {
        paddingVertical: 10,
        paddingHorizontal: 16,
    },
    dropdownItemFirst: {
        borderTopLeftRadius: 12,
        borderTopRightRadius: 12,
    },
    dropdownItemLast: {
        borderBottomLeftRadius: 12,
        borderBottomRightRadius: 12,
    },
    dropdownItemActive: {
        backgroundColor: '#007bff',
    },
    dropdownItemText: {
        color: '#333',
    },
    dropdownItemTextActive: {
        color: '#fff',
        fontWeight: 'bold',
    },
});

