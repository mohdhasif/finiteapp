import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    Dimensions,
    Linking,
    Alert,
    TextInput,
    RefreshControl,
    ActivityIndicator,
    KeyboardAvoidingView,
    Platform,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { useRoute, RouteProp, useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/types';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../context/AuthContext';
import AccessRestrictedModal from '../components/AccessRestrictedModal';
import {
    listAttachments,
    getTaskLink,
    listNotes,
    addNote,
    type TaskAttachment,
    type TaskNote,
} from '../services/taskDetailsService';
import { BASE_URL } from '../constants/apiConfig';
import { getTaskDetails } from '../services/taskService';

const { width } = Dimensions.get('window');
type TaskDetailsScreenRouteProp = RouteProp<RootStackParamList, 'TaskDetailsScreen'>;

    // Normalize date → milliseconds (handle "YYYY-MM-DD HH:mm:ss" or ISO)
const toMs = (s?: string) => {
    if (!s) return 0;
    const iso = s.includes('T') ? s : s.replace(' ', 'T') + 'Z';
    const t = Date.parse(iso);
    return Number.isFinite(t) ? t : 0;
};
    // Sort helper: oldest → newest (use load time only)
const sortOldest = (arr: TaskNote[]) => arr.slice().sort((a, b) => toMs(a.created_at) - toMs(b.created_at));

const TaskDetailsScreen = () => {
    const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
    const route = useRoute<TaskDetailsScreenRouteProp>();
    const { clientStatus } = useAuth();
    const [showRestrictedModal, setShowRestrictedModal] = useState(false);
    const taskId = route.params?.task_id as number || 0;
    const taskTitle = route.params?.task_title ?? 'Task';

    const [token, setToken] = useState<string>('');
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    // Attachments
    const [attachments, setAttachments] = useState<TaskAttachment[]>([]);

    // Single Link
    const [linkUrl, setLinkUrlState] = useState<string>('');

    // Notes
    const [notes, setNotes] = useState<TaskNote[]>([]);
    const [noteText, setNoteText] = useState('');
    const [sendingNote, setSendingNote] = useState(false);
    const canSend = useMemo(() => noteText.trim().length > 0, [noteText]);

    const outerScrollRef = useRef<ScrollView>(null); // overall scroll
    const notesBottomAnchor = useRef<View>(null);     // anchor for scroll to bottom

    const [taskDetails, setTaskDetails] = useState<any>(null);

    const toAbs = useCallback((u?: string | null) => {
        if (!u) return '';
        if (/^https?:\/\//i.test(u)) return u;
        return `${BASE_URL.replace(/\/+$/, '')}/${String(u).replace(/^\/+/, '')}`;
    }, []);

    const loadAll = useCallback(async (tk: string) => {
        try {
            setLoading(true);
            const [att, lk, ns, td] = await Promise.all([
                listAttachments(tk, taskId),
                getTaskLink(tk, taskId),
                listNotes(tk, taskId),
                getTaskDetails(tk, taskId),
            ]);
            setAttachments(att ?? []);
            setLinkUrlState(lk?.url ?? '');
            setNotes(sortOldest(ns ?? []));
            setTaskDetails(td ?? null);
        } catch (e: any) {
            Alert.alert('Failed to load', e?.message || 'Unknown error');
        } finally {
            setLoading(false);
        }
    }, [taskId]);

    const onRefresh = useCallback(async () => {
        if (!token) return;
        setRefreshing(true);
        try {
            await loadAll(token);
        } finally {
            setRefreshing(false);
        }
    }, [token, loadAll]);

    useEffect(() => {
        (async () => {
            const tk = (await AsyncStorage.getItem('userToken')) || '';
            setToken(tk);
            if (!taskId) {
                Alert.alert('Error', 'taskId is missing.');
                return;
            }
            await loadAll(tk);
        })();
    }, [taskId, loadAll]);

    // ===== Actions (view-only for attachments/links; notes can be added) =====

    const normalizeUrl = (s: string) => {
        const trimmed = (s || '').trim();
        return /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
    };

    const handleOpenLink = async () => {
        if (!linkUrl?.trim()) return;
        const url = normalizeUrl(linkUrl);

        try {
            await Linking.openURL(url); // keep trying
        } catch (e) {
            Alert.alert('Invalid link', 'URL cannot be opened. Make sure you have a browser or try again.');
        }
    };

    // No link saving on client side

    const handleSendNote = async () => {
        if (clientStatus === 'barred') {
            setShowRestrictedModal(true);
            return;
        }
        if (!token || !canSend) return;
        setSendingNote(true);
        try {
            const note = await addNote(token, {
                task_id: taskId,
                sender_type: 'client',
                message: noteText.trim(),
            });

            // Fallback created_at if server doesn't provide, so it doesn't sort weirdly
            const safeNote: TaskNote = {
                ...note,
                created_at: note.created_at && note.created_at.trim() ? note.created_at : new Date().toISOString(),
            };

            // DON'T sort here — just APPEND to keep at bottom
            setNotes((prev) => [...prev, safeNote]);
            setNoteText('');

            // Auto-scroll to bottom to show new note
            requestAnimationFrame(() => {
                outerScrollRef.current?.scrollToEnd({ animated: true });
            });
        } catch (e: any) {
            Alert.alert('Failed to send note', e?.message || 'Unknown error');
        } finally {
            setSendingNote(false);
        }
    };

    return (
        <KeyboardAvoidingView 
            style={styles.container} 
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
        >
            <ScrollView
                ref={outerScrollRef}
                contentContainerStyle={styles.scrollContent}
                refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
                keyboardShouldPersistTaps="handled"
                showsVerticalScrollIndicator={false}
            >
                {/* Header */}
                <Text style={styles.header}>Task Details</Text>
                <Text style={styles.title}>{taskTitle}</Text>

                {/* Description */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>
                        <Text style={styles.bullet}>● </Text>Description
                    </Text>
                    <Text style={styles.description}>
                        {taskDetails?.description || 'No description.'}
                    </Text>
                </View>

                {/* Attachments */}
                <View style={styles.cardBlock}>
                    <View style={styles.cardHeaderRow}>
                        <Text style={styles.cardTitle}>● Attachments</Text>
                        {/* <TouchableOpacity style={styles.iconBtn} onPress={handlePickAndUpload} disabled={uploading}>
                            {uploading ? (
                                <ActivityIndicator size="small" color="#fff" />
                            ) : (
                                <Icon name="cloud-upload-outline" size={18} color="#fff" />
                            )}
                            <Text style={styles.iconBtnText}>{uploading ? 'Uploading...' : 'Upload'}</Text>
                        </TouchableOpacity> */}
                    </View>

                    {loading && attachments.length === 0 ? (
                        <Text style={styles.muted}>Loading attachments…</Text>
                    ) : attachments.length === 0 ? (
                        <Text style={styles.muted}>No attachments.</Text>
                    ) : (
                        attachments.map((att) => (
                            <View key={att.id} style={styles.attachmentRow}>
                                <View style={{ flex: 1 }}>
                                    <Text style={styles.attachmentName} numberOfLines={1}>
                                        {att.file_name || 'file'}
                                    </Text>
                                    <TouchableOpacity onPress={() => Linking.openURL(toAbs(att.file_url))}>
                                        <Text style={styles.attachmentUrl} numberOfLines={1}>
                                            {toAbs(att.file_url)}
                                        </Text>
                                    </TouchableOpacity>
                                </View>
                                <TouchableOpacity onPress={() => Linking.openURL(toAbs(att.file_url))} style={styles.viewBtn}>
                                    <Icon name="open-outline" size={20} color="#fff" />
                                </TouchableOpacity>
                            </View>
                        ))
                    )}
                </View>

                {/* Single Link */}
                <View style={styles.cardBlock}>
                    <Text style={styles.cardTitle}>● Link</Text>
                    <View style={styles.linkRow}>
                        <TextInput
                            placeholder="https://example.com/doc"
                            placeholderTextColor="#9dc9e4"
                            style={styles.input}
                            value={linkUrl}
                            onChangeText={setLinkUrlState}
                            autoCapitalize="none"
                            autoCorrect={false}
                            editable={false}
                        />
                    </View>
                    <View style={styles.rowActions}>
                        <TouchableOpacity style={styles.secondaryBtn} onPress={handleOpenLink} disabled={!linkUrl}>
                            <Icon name="open-outline" size={18} color="#fff" />
                            <Text style={styles.secondaryBtnText}>Open</Text>
                        </TouchableOpacity>
                        {/* <TouchableOpacity style={styles.primaryBtn} onPress={handleSaveLink} disabled={savingLink}>
                            {savingLink ? (
                                <ActivityIndicator size="small" color="#0B2C3F" />
                            ) : (
                                <Icon name="save-outline" size={18} color="#0B2C3F" />
                            )}
                            <Text style={styles.primaryBtnText}>{savingLink ? 'Saving…' : 'Save'}</Text>
                        </TouchableOpacity> */}
                    </View>
                </View>

                {/* Notes */}
                <View style={styles.cardBlock}>
                    <Text style={styles.cardTitle}>● Notes</Text>

                    {/* Note list (oldest → newest) — sorted during load */}
                    {loading && notes.length === 0 ? (
                        <Text style={styles.muted}>Loading notes…</Text>
                    ) : notes.length === 0 ? (
                        <Text style={styles.muted}>No notes yet.</Text>
                    ) : (
                        notes.map((n) => (
                            <View key={n.id} style={styles.noteRow}>
                                <View style={styles.noteBadge}>
                                    <Text style={styles.noteBadgeText}>{n.sender_type === 'admin' ? 'A' : 'C'}</Text>
                                </View>
                                <View style={{ flex: 1 }}>
                                    <Text style={styles.noteMeta}>
                                        {n.sender_type.toUpperCase()} · {new Date(toMs(n.created_at)).toLocaleString()}
                                    </Text>
                                    <Text style={styles.noteText}>{n.message}</Text>
                                </View>
                            </View>
                        ))
                    )}

                    {/* INPUT di PALING BAWAH */}
                    <View style={[styles.noteInputBox, { marginTop: 12 }]}>
                        <TextInput
                            placeholder="Write a note…"
                            placeholderTextColor="#9dc9e4"
                            style={styles.textarea}
                            value={noteText}
                            onChangeText={setNoteText}
                            multiline
                        />
                        <TouchableOpacity
                            style={[styles.primaryBtn, { alignSelf: 'flex-end', marginTop: 10, opacity: clientStatus === 'barred' ? 0.5 : (canSend ? 1 : 0.6) }]}
                            onPress={handleSendNote}
                            disabled={clientStatus === 'barred' || !canSend || sendingNote}
                        >
                            {sendingNote ? (
                                <ActivityIndicator size="small" color="#0B2C3F" />
                            ) : (
                                <Icon name="send-outline" size={18} color="#0B2C3F" />
                            )}
                            <Text style={styles.primaryBtnText}>{sendingNote ? 'Sending…' : 'Send'}</Text>
                        </TouchableOpacity>
                    </View>

                    {/* Anchor untuk scrollToEnd yang tepat */}
                    <View ref={notesBottomAnchor} />
                </View>

                <View style={{ height: 120 }} />
            </ScrollView>

            {/* Bottom Nav */}
            <View style={styles.bottomNav}>
                <TouchableOpacity 
                    style={[styles.navItem, clientStatus === 'barred' && { opacity: 0.5 }]} 
                    onPress={() => {
                        if (clientStatus === 'barred') {
                            setShowRestrictedModal(true);
                        } else {
                            navigation.navigate('NotificationsScreen');
                        }
                    }}
                >
                    <Icon name="notifications-outline" size={26} color="#fff" />
                </TouchableOpacity>

                <TouchableOpacity 
                    style={[styles.navItem, clientStatus === 'barred' && { opacity: 0.5 }]} 
                    onPress={() => {
                        if (clientStatus === 'barred') {
                            setShowRestrictedModal(true);
                        } else {
                            navigation.navigate('ProjectListScreen');
                        }
                    }}
                >
                    <Icon name="home-outline" size={26} color="#fff" />
                </TouchableOpacity>

                <TouchableOpacity style={styles.navItem} onPress={() => navigation.navigate('ProfileScreen')}>
                    <Icon name="person-outline" size={26} color="#fff" />
                </TouchableOpacity>
            </View>

            {/* Access Restricted Modal */}
            <AccessRestrictedModal
                visible={showRestrictedModal}
                onClose={() => setShowRestrictedModal(false)}
                title="Access Restricted"
                message="Your account is currently restricted. You cannot access this feature."
            />
        </KeyboardAvoidingView>
    );
};

export default TaskDetailsScreen;

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#0B2C3F' },
    scrollContent: { padding: 20 },
    header: { fontSize: 26, color: '#fff', fontWeight: 'bold' },
    title: { fontSize: 20, color: '#fff', marginBottom: 20 },

    section: {
        backgroundColor: '#0E4766',
        padding: 15,
        borderRadius: 10,
        borderColor: '#1DA1F2',
        borderWidth: 1,
        marginBottom: 20,
    },
    sectionTitle: { color: '#fff', fontWeight: 'bold', fontSize: 16, marginBottom: 8 },
    bullet: { color: '#fff', fontSize: 16 },
    description: { color: '#ccc', fontSize: 14, lineHeight: 20 },

    cardBlock: {
        backgroundColor: '#12668C',
        padding: 15,
        borderRadius: 10,
        marginBottom: 15,
    },
    cardHeaderRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
    cardTitle: { color: '#fff', fontSize: 16, marginBottom: 10 },

    iconBtn: {
        flexDirection: 'row',
        gap: 8,
        backgroundColor: '#0B2C3F',
        borderRadius: 8,
        paddingVertical: 8,
        paddingHorizontal: 12,
        alignItems: 'center',
    },
    iconBtnText: { color: '#fff', fontWeight: '600' },

    attachmentRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        backgroundColor: '#0E4766',
        padding: 10,
        borderRadius: 8,
        marginBottom: 8,
    },
    attachmentName: { color: '#fff', fontSize: 14, fontWeight: '600' },
    attachmentUrl: { color: '#9ddcff', fontSize: 12, marginTop: 2 },
    deleteBtn: {
        backgroundColor: '#d9534f',
        width: 36,
        height: 36,
        borderRadius: 8,
        alignItems: 'center',
        justifyContent: 'center',
    },
    viewBtn: {
        backgroundColor: '#1DA1F2',
        width: 36,
        height: 36,
        borderRadius: 8,
        alignItems: 'center',
        justifyContent: 'center',
    },

    linkRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    input: {
        flex: 1,
        backgroundColor: '#0E4766',
        borderRadius: 8,
        paddingHorizontal: 12,
        paddingVertical: 10,
        color: '#fff',
        borderWidth: 1,
        borderColor: '#1DA1F2',
    },
    rowActions: { flexDirection: 'row', gap: 10, marginTop: 10, justifyContent: 'flex-end' },
    secondaryBtn: {
        flexDirection: 'row',
        gap: 8,
        backgroundColor: '#0E4766',
        borderRadius: 8,
        paddingVertical: 8,
        paddingHorizontal: 12,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#1DA1F2',
    },
    secondaryBtnText: { color: '#fff', fontWeight: '600' },
    primaryBtn: {
        flexDirection: 'row',
        gap: 8,
        backgroundColor: '#fff',
        borderRadius: 8,
        paddingVertical: 8,
        paddingHorizontal: 12,
        alignItems: 'center',
    },
    primaryBtnText: { color: '#0B2C3F', fontWeight: '700' },

    noteInputBox: {
        backgroundColor: '#0E4766',
        borderRadius: 10,
        borderColor: '#1DA1F2',
        borderWidth: 1,
        padding: 12,
        marginBottom: 0,
    },
    textarea: {
        minHeight: 80,
        color: '#fff',
        textAlignVertical: 'top',
    },
    noteRow: {
        flexDirection: 'row',
        gap: 10,
        backgroundColor: '#0E4766',
        borderRadius: 10,
        padding: 12,
        marginBottom: 8,
    },
    noteBadge: {
        width: 28,
        height: 28,
        borderRadius: 14,
        backgroundColor: '#1DA1F2',
        alignItems: 'center',
        justifyContent: 'center',
    },
    noteBadgeText: { color: '#0B2C3F', fontWeight: '800' },
    noteMeta: { color: '#9dc9e4', fontSize: 11, marginBottom: 4 },
    noteText: { color: '#fff', fontSize: 14 },
    muted: { color: '#cfe7f6', opacity: 0.7 },

    bottomNav: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        width: width,
        height: 70,
        backgroundColor: '#007baf',
        borderTopLeftRadius: 24,
        borderTopRightRadius: 24,
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'center',
        paddingBottom: 10,
        zIndex: 1000,
        elevation: 10,
    },
    navItem: {
        position: 'relative',
        alignItems: 'center',
        justifyContent: 'center',
    },
});
